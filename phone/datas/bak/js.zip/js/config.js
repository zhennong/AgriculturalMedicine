/**
 * Created by wodrow on 1/23/16.
 */
var config = {
    alias:{
        APP_NAME : 'Agricultural medicine'
    },
    sourceUrl : "http://www.dt50.cn/touchknow/",
    apiUrl : "http://www.dt50.cn/touchknow/api_app_know.php"
};